<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Lot Viewer - Coming Soon</title>
  <style>
    body {
      font-family: "Times New Roman", Times, serif;
      margin: 0;
      padding: 0;
      background-color: #003E7E;  /* UT Blue */
      color: #FFB81C;             /* UT Gold text */
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }

    .container {
      text-align: center;
      border: 4px solid #FFB81C;
      border-radius: 12px;
      padding: 40px 60px;
      background-color: #002B55;
      box-sizing: border-box;
    }

    .title {
      font-size: 36px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .subtitle {
      font-size: 18px;
      margin-bottom: 25px;
    }

    .message {
      font-size: 16px;
      margin-bottom: 30px;
      max-width: 400px;
      margin-left: auto;
      margin-right: auto;
      line-height: 1.4;
    }

    .badge-row {
      display: flex;
      justify-content: center;
      gap: 16px;
      margin-bottom: 30px;
    }

    .badge {
      border-radius: 999px;
      border: 2px solid #FFB81C;
      padding: 6px 14px;
      font-size: 13px;
    }

    .btn {
      display: inline-block;
      margin-top: 10px;
      padding: 10px 20px;
      border-radius: 6px;
      border: 2px solid #FFB81C;
      background-color: #FFB81C;
      color: #003E7E;
      font-weight: bold;
      font-size: 14px;
      text-decoration: none;
      cursor: pointer;
    }

    .btn:hover {
      background-color: #003E7E;
      color: #FFB81C;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="title">Lot Viewer</div>
    <div class="subtitle">Coming Soon</div>

    <div class="message">
      We’re building an interactive parking lot viewer that will show live
      spot availability, disabled spaces, and a detailed layout for each lot.
      Check back soon to see the full experience.
    </div>

    <div class="badge-row">
      <div class="badge">Prototype Phase</div>
      <div class="badge">UT Parking Project</div>
    </div>

    <!-- Link back to your home page (change file name if needed) -->
    <a href="Home.php" class="btn">Back to Home</a>
  </div>
</body>
</html>
