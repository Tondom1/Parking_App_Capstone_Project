<!DOCTYPE html>
<html>
<head>
    <title>App Prototype</title>
</head>
<body style="background:;color:blue;font-family:Arial;text-align:center;margin-top:20%;">
  <h1>Test works</h1>
  <p>Test Works</p>
</body>
</html>
