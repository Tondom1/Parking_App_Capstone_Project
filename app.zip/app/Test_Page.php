<!-- Save as layout_test.php -->
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Parking Layout Test</title>
  <style>
    body {
      font-family: "Times New Roman", Times, serif;
      margin: 0;
      padding: 0;
      background-color: #003E7E;  /* UT Blue */
      color: #FFB81C;             /* UT Gold text */
    }

    .page {
      display: flex;
      height: 100vh;
    }

    .sidebar {
      width: 220px;
      background: #003E7E; 
      border-right: 4px solid #FFB81C;
      padding: 20px;
    }

    /* Sidebar "Lots" title — now same size as Lot Layout */
    .sidebar-title {
      color: #FFB81C;
      font-weight: bold;
      text-align: center;
      margin-bottom: 20px;
      font-size: 32px;  /* same size as Lot Layout */
    }

    .main {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: #FFB81C; /* gold text inside main area */
    }

    h2 {
      color: #FFB81C;
      font-size: 32px; /* ensure consistent size */
    }

    .lot-list {
      margin-bottom: 30px;
    }

    .lot-item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      padding: 8px;
      background: #004A9F;
      border-radius: 4px;
      color: #FFB81C;
      border: 2px solid #FFB81C;
    }

    .color-box {
      width: 20px;
      height: 30px;
      border-radius: 4px;
      margin-right: 10px;
      border: 1px solid #FFB81C;
    }

    .lot1-color {
      background-color: #003E7E; /* UT Blue */
    }

    .lot2-color {
      background-color: #FFB81C; /* UT Gold */
    }

    .grid {
      border: 4px solid #FFB81C;
      padding: 40px;
      display: grid;
      grid-template-columns: repeat(10, 60px);
      grid-auto-rows: 60px;
      gap: 20px;
      margin-top: 20px;
      background-color: black;
      border-radius: 8px;
    }

    .spot {
      background: #ccc;
      border: 4px solid black;  /* Black perimeter by default */
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: black;
      font-weight: bold;
      transition: border-color 0.3s, background-color 0.3s;
    }

    /* Disabled parking spot (UT blue border, light blue background) */
    .spot.disabled {
      border-color: #003E7E;  /* UT Blue border */
      background: #B0C4DE;    /* Light steel blue background */
      color: #003E7E;
      font-weight: bold;
    }

    .cam-box {
      margin-top: 30px;
      border: 1px dashed #FFB81C;
      padding: 10px;
      text-align: center;
      color: #FFB81C;
      font-size: 14px;
      background-color: #004A9F;
      border-radius: 4px;
    }
  </style>
</head>
<body>
  <div class="page">
    <!-- Sidebar -->
    <div class="sidebar">
      <h3 class="sidebar-title">Lots</h3>
      <div class="lot-list">
        <div class="lot-item">
          <div class="color-box lot1-color"></div>
          Lot 1
        </div>
        <div class="lot-item">
          <div class="color-box lot2-color"></div>
          Lot 2
        </div>
      </div>
    </div>

    <!-- Main Area -->
    <div class="main">
      <h2>Lot Layout</h2>
      <div class="grid">
        <!-- Regular black border spots -->
        <div class="spot">1</div>
        <div class="spot">2</div>
        <div class="spot">3</div>
        <div class="spot">4</div>
        <div class="spot">5</div>
        <div class="spot">6</div>
        <div class="spot">7</div>
        <div class="spot">8</div>
        <div class="spot">9</div>

        <!-- Disabled spots (blue border) -->
        <div class="spot disabled">10</div>

        <!-- Regular black border spots -->
        <div class="spot">11</div>
        <div class="spot">12</div>
        <div class="spot">13</div>
        <div class="spot">14</div>
        <div class="spot">15</div>
        <div class="spot">16</div>
        <div class="spot">17</div>
        <div class="spot">18</div>
        <div class="spot">19</div>

        <!-- Disabled spot -->
        <div class="spot disabled">20</div>
      </div>
    </div>
  </div>
</body>
</html>
