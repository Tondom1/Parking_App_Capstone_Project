<?php
require 'db.php';
echo "Connected to MySQL successfully!";
