<!DOCTYPE html>
<html>
    <body>
        <?php
        echo "Link Page";
        ?>
    </body>
</html>
