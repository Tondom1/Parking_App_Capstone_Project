<!DOCTYPE html>
<html>
    <body>
        <?php
        echo "Hello";
        echo '<a href="link.php">Go to link page</a>';
        ?>
    </body>
</html>
