<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Lot Viewer - Coming Soon</title>
  <style>

    body {
      font-family: "Times New Roman", Times, serif;
      margin: 0;
      padding: 0;
      background-color: #003E7E;  /* UT Blue */
      color: #FFB81C;             /* UT Gold text */
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 220px;
      background: #002B55; 
      border-right: 4px solid #FFB81C;
      padding: 20px;
    }

    /* Sidebar "Lots" title — now same size as Lot Layout */
    .sidebar-title {
      color: #FFB81C;
      font-weight: bold;
      text-align: center;
      margin-bottom: 20px;
      font-size: 32px;  /* same size as Lot Layout */
    }

    .main {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: #FFB81C; /* gold text inside main area */
    }

    .lot-list {
      margin-bottom: 30px;
    }

    .lot-item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      padding: 8px;
      background: #004A9F;
      border-radius: 4px;
      color: #FFB81C;
      border: 2px solid #FFB81C;
    }

    .color-box {
      width: 20px;
      height: 30px;
      border-radius: 4px;
      margin-right: 10px;
      border: 1px solid #FFB81C;
    }

    .lot1-color {
      background-color: #003E7E; /* UT Blue */
    }

    .lot2-color {
      background-color: #FFB81C; /* UT Gold */
    }

    .home-color {
      background-color: #555555;
    }

    .container {
      text-align: center;
      border: 4px solid #FFB81C;
      border-radius: 12px;
      padding: 40px 60px;
      background-color: #002B55;
      box-sizing: border-box;
    }

    .title {
      font-size: 36px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .subtitle {
      font-size: 18px;
      margin-bottom: 25px;
    }

    .message {
      font-size: 16px;
      margin-bottom: 30px;
      max-width: 400px;
      margin-left: auto;
      margin-right: auto;
      line-height: 1.4;
    }

    .badge-row {
      display: flex;
      justify-content: center;
      gap: 16px;
      margin-bottom: 30px;
    }

    .badge {
      border-radius: 999px;
      border: 2px solid #FFB81C;
      padding: 6px 14px;
      font-size: 13px;
    }

    .btn {
      display: inline-block;
      margin-top: 10px;
      padding: 10px 20px;
      border-radius: 6px;
      border: 2px solid #FFB81C;
      background-color: #FFB81C;
      color: #003E7E;
      font-weight: bold;
      font-size: 14px;
      text-decoration: none;
      cursor: pointer;
    }

    .btn:hover {
      background-color: #003E7E;
      color: #FFB81C;
    }

    a {
      color: inherit;
    }
  </style>
</head>
<body>
  <div class="sidebar">
      <h3 class="sidebar-title">Lots</h3>
      <div class="lot-list">
        <div class="lot-item">
          <div class="color-box home-color"></div>
          <a href="Home.php">Lot Explorer</a>
        </div>
        <div class="lot-item">
          <div class="color-box lot1-color"></div>
          <a href="Lot 1.php">Lot 1</a>
        </div>
        <div class="lot-item">
          <div class="color-box lot2-color"></div>
          <a href="Coming Soon.php">Lot 2</a>
        </div>
      </div>
    </div>
  <div class = "main">
  <div class="container">
    <div class="title">Installation In Progress</div>
    <div class="subtitle">Coming Soon</div>

    <div class="message">
      We are working on intalling cameras in more lots. Come back again to check on our progress!
    </div>

    <!-- Link back to your home page (change file name if needed) -->
    <a href="Home.php" class="btn">Back to Home</a>
    </div>
  </div>
</body>
</html>
