<?php
// Show errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'db_connect.php';

// Change 'spaces' to your real table name
$sql = "SELECT * FROM spaces";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Parking DB Test</title>
</head>
<body>
  <h1>Parking Database Test</h1>

  <?php if (!$result): ?>
    <p>Query error: <?php echo $conn->error; ?></p>
  <?php else: ?>
    <table border="1" cellpadding="5">
      <tr>
        <?php
        // print column headers dynamically
        if ($result->num_rows > 0) {
            $firstRow = $result->fetch_assoc();
            foreach ($firstRow as $colName => $value) {
                echo "<th>" . htmlspecialchars($colName) . "</th>";
            }
            echo "</tr><tr>";
            // print first row values
            foreach ($firstRow as $value) {
                echo "<td>" . htmlspecialchars($value) . "</td>";
            }
            // print rest of rows
            while ($row = $result->fetch_assoc()) {
                echo "</tr><tr>";
                foreach ($row as $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                }
            }
        } else {
            echo "<p>No rows found in table.</p>";
        }
        ?>
      </tr>
    </table>
  <?php endif; ?>

</body>
</html>
