<html>
    <head>
        <meta http-equiv="refresh" content="3">
    </head>
</html>

<?php
// ***** DATABASE SETTINGS *****
// Change this to the IP address of your Raspberry Pi
$host = '172.31.63.121';   // <-- Replace with your Pi's IP (PI_IP)
$user = 'Curtis_Laptop';
$pass = 'root';
$db   = 'parking';

// ***** CONNECT *****
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "<h2>Connected successfully to database!</h2>";

// ***** SIMPLE QUERY EXAMPLE *****
// Change 'spots' and column names to match your actual table
$sql = "SELECT * FROM lot1 LIMIT 20";
$result = $conn->query($sql);

if (!$result) {
    die("Query error: " . $conn->error);
}

echo "<h3>Sample rows from 'spots' table:</h3>";
echo "<table border='1' cellpadding='5'>";
echo "<th>SpotNumber</th><th>Status</th></tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    if ($row['is_handicap'] == 1)
    {
        echo "<td>" . htmlspecialchars("HS " . $row['spot_id']) . "</td>";
    }
    else {
        echo "<td>" . htmlspecialchars($row['spot_id']) . "</td>";
    }
    if ($row['is_occupied'] == 1)
    {
        echo "<td>" . htmlspecialchars('Full') . "</td>";
    }
    else{
       echo "<td>" . htmlspecialchars('Empty') . "</td>";
    }
    echo "</tr>";
}

echo "</table>";

$conn->close();
?>
