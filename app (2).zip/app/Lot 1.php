<!-- Save as layout_test.php -->
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="3">
  <title>Parking Layout Test</title>
  <style>
    body {
      font-family: "Times New Roman", Times, serif;
      margin: 0;
      padding: 0;
      background-color: #003E7E;  /* UT Blue */
      color: #FFB81C;             /* UT Gold text */
    }

    .page {
      display: flex;
      height: 100vh;
    }

    .sidebar {
      width: 220px;
      background: #002B55; 
      border-right: 4px solid #FFB81C;
      padding: 20px;
    }

    /* Sidebar "Lots" title — now same size as Lot Layout */
    .sidebar-title {
      color: #FFB81C;
      font-weight: bold;
      text-align: center;
      margin-bottom: 20px;
      font-size: 32px;  /* same size as Lot Layout */
    }

    .main {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: #FFB81C; /* gold text inside main area */
    }

    h2 {
      color: #FFB81C;
      font-size: 32px; /* ensure consistent size */
    }

    .lot-list {
      margin-bottom: 30px;
    }

    .lot-item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      padding: 8px;
      background: #004A9F;
      border-radius: 4px;
      color: #FFB81C;
      border: 2px solid #FFB81C;
    }

    .color-box {
      width: 20px;
      height: 30px;
      border-radius: 4px;
      margin-right: 10px;
      border: 1px solid #FFB81C;
    }

    .lot1-color {
      background-color: #003E7E; /* UT Blue */
    }

    .lot2-color {
      background-color: #FFB81C; /* UT Gold */
    }

    .home-color {
      background-color: #555555;
    }

    .grid {
      border: 4px solid #FFB81C;
      padding: 40px;
      display: grid;
      grid-template-columns: repeat(11, 60px);
      grid-auto-rows: 60px;
      gap: 20px;
      margin-top: 20px;
      background-color: #002B55;
      border-radius: 8px;
    }

    .spot {
      background: #61df61ff;
      border: 4px solid black;  /* Black perimeter by default */
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: black;
      font-weight: bold;
      transition: border-color 0.3s, background-color 0.3s;
    }

    /* Disabled parking spot (UT blue border, light blue background) */
    .spot.disabled {
      border-color: #1284f6ff;  /* UT Blue border */
      background: #61df61ff;    /* Light steel blue background */
      color: #000000;
      font-weight: bold;
    }

    .spot.disabled.occupied {
      border-color: #1284f6ff;  /* UT Blue border */
      background: #ef3f3fff;    /* Light steel blue background */
      color: #000000;
      font-weight: bold;
    }

    .spot.occupied {
      background: #ef3f3fff;
      border: 4px solid black;  /* Black perimeter by default */
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: black;
      font-weight: bold;
      transition: border-color 0.3s, background-color 0.3s;
    }

    .cam-box {
      margin-top: 30px;
      border: 1px dashed #FFB81C;
      padding: 10px;
      text-align: center;
      color: #FFB81C;
      font-size: 14px;
      background-color: #004A9F;
      border-radius: 4px;
    }

    a {
      color: inherit;
    }
  </style>
</head>

<body>
  <div class="page">
    <!-- Sidebar -->
    <div class="sidebar">
      <h3 class="sidebar-title">Lots</h3>
      <div class="lot-list">
        <div class="lot-item">
          <div class="color-box home-color"></div>
          <a href="Home.php">Lot Explorer</a>
        </div>
        <div class="lot-item">
          <div class="color-box lot1-color"></div>
          <a href="Lot 1.php">Lot 1</a>
        </div>
        <div class="lot-item">
          <div class="color-box lot2-color"></div>
          <a href="Coming Soon.php">Lot 2</a>
        </div>
      </div>
    </div>

    <!-- Main Area -->
    <div class="main">
      <h2>Lot Layout</h2>
      <div class="grid">
         <?php

         $host = '172.31.63.121';   // Server IP Address
         $user = 'Curtis_Laptop';
         $pass = 'root';
         $db   = 'parking';

         // ***** CONNECT *****
         $conn = new mysqli($host, $user, $pass, $db);

         // Check connection
         if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
         }
         
         $sql = "SELECT * FROM lot1 LIMIT 20";
         $result = $conn->query($sql);

        
          $count = 1;
         while ($row = $result->fetch_assoc()) {
          if ($row['is_handicap'] == 1)
          {
            if ($row['is_occupied'] == 1)
            {
              echo "<div class=\"spot disabled occupied\">$count</div>";
            }
            else{
              echo "<div class=\"spot disabled\">$count</div>";
            }
          }
          else {
              if ($row['is_occupied'] == 1)
              {
                echo "<div class=\"spot occupied\">$count</div>";
              }
              else{
                echo "<div class=\"spot\">$count</div>";
              }
          }
          ++$count;
      }
         ?>
      </div>
      <?php
      echo "<h2>Connected successfully to database</h2>";
      ?>
    </div>
  </div>
</body>
</html>
