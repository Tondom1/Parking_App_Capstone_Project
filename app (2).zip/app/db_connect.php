<?php
// db_connect.php

// CHANGE THIS to your Pi's IP address
$host = '172.31.16.168';   // e.g. 172.31.16.168
$db   = 'parking';         // your existing database name
$user = 'Curtis_Laptop';   // DB user on the Pi
$pass = 'root';            // DB password

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>