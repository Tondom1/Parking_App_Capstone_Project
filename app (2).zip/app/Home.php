<!-- Save as index.php -->
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="3">
  <title>UT Parking Availability</title>
  <style>
    body {
      font-family: "Times New Roman", Times, serif;
      margin: 0;
      padding: 0;
      background-color: #003E7E;  /* UT Blue */
      color: #FFB81C;             /* UT Gold */
    }

    .page {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Top header bar */
    .header {
      background-color: #002B55;
      padding: 20px;
      border-bottom: 4px solid #FFB81C;
      text-align: center;
    }

    .header-title {
      margin: 0;
      font-size: 40px;
      font-weight: bold;
    }

    .header-subtitle {
      margin: 5px 0 0 0;
      font-size: 18px;
    }

    /* Main content area */
    .content {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      padding: 40px 20px;
    }

    .section-title {
      font-size: 28px;
      margin-bottom: 20px;
      text-align: center;
    }

    /* Lot cards container */
    .lot-grid {
      display: grid;
      grid-template-columns: repeat(2, 260px);
      gap: 30px;
      max-width: 900px;
      width: 100%;
      justify-content: center;
    }

    .lot-card {
      background-color: white;
      color: black;
      border-radius: 8px;
      border: 3px solid #FFB81C;
      padding: 16px;
      box-sizing: border-box;
    }

    .lot-name {
      font-size: 22px;
      font-weight: bold;
      text-align: center;
      margin-bottom: 10px;
    }

    .lot-tagline {
      font-size: 14px;
      text-align: center;
      margin-bottom: 12px;
      color: #333;
    }

    /* Availability bar */
    .availability-bar {
      height: 18px;
      background-color: #ddd;
      border-radius: 9px;
      overflow: hidden;
      margin-bottom: 8px;
      border: 1px solid #999;
    }

    .availability-fill {
      height: 100%;
      background-color: #2ECC40; /* green for available portion */
      width: 60%;                /* change this to visually show fullness */
    }

    .availability-text {
      font-size: 14px;
      text-align: center;
      margin-bottom: 12px;
    }

    .status-pill {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 13px;
      font-weight: bold;
      margin-bottom: 12px;
      align-content: center;
    }

    .status-good {
      background-color: #2ECC40;
      color: white;
    }

    .status-medium {
      background-color: #FFB81C;
      color: black;
    }

    .status-bad {
      background-color: #E74C3C;
      color: black;
    }

    .view-button {
      display: inline-block;
      text-decoration: none;
      text-align: center;
      margin-top: 8px;
      padding: 8px 14px;
      border-radius: 6px;
      border: 2px solid #003E7E;
      background-color: #003E7E;
      color: #FFB81C;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
    }

    .view-button:hover {
      background-color: #FFB81C;
      color: #003E7E;
    }

    /* Footer */
    .footer {
      text-align: center;
      padding: 10px;
      font-size: 12px;
      background-color: #002B55;
      border-top: 2px solid #FFB81C;
    }

    @media (max-width: 900px) {
      .lot-grid {
        grid-template-columns: repeat(1, 260px);
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <!-- Header -->
    <div class="header">
      <h1 class="header-title">UT Parking Availability</h1>
      <p class="header-subtitle">Quick view of campus lot occupancy</p>
    </div>

    <!-- Main content -->
    <div class="content">
      <h2 class="section-title">Select a Parking Lot</h2>

      <div class="lot-grid">
        <!-- Lot 1 card -->

        <div class="lot-card">
          <div class="lot-name">Lot 1</div>
          <div class="lot-tagline">Near North Engineering Building</div>
          <?php

          $host = '172.31.63.121';   // <-- Replace with your Pi's IP (PI_IP)
          $user = 'Curtis_Laptop';
          $pass = 'root';
          $db   = 'parking';

          // ***** CONNECT *****
          $conn = new mysqli($host, $user, $pass, $db);

          // Check connection
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }
          $carCount = 0;
          $carTotal = 0;

          $sql = "SELECT * FROM lot1 LIMIT 20";
          $result = $conn->query($sql);

          if (!$result) {
              die("Query error: " . $conn->error);
          }

          while ($row = $result->fetch_assoc()) {
            if ($row['is_occupied'] == 1) {
              $carCount++;
            }
            $carTotal++;
          }
          $carPercentage = ($carCount / $carTotal) * 100;
          $carPercentageString = (string)$carPercentage . "%";
            echo "<div class=\"availability-bar\">";
            if ($carPercentage >= 0 && $carPercentage <=50)
            {
              echo "<div class=\"availability-fill\" style=\"width: $carPercentageString; background-color: #2ECC40;\"></div>";
            }
            else if ($carPercentage > 50 && $carPercentage <= 85)
            {
              echo "<div class=\"availability-fill\" style=\"width: $carPercentageString; background-color: #FFB81C;\"></div>";
            }
            else{
              echo "<div class=\"availability-fill\" style=\"width: $carPercentageString; background-color: #E74C3C;\"></div>";
            }
            echo "</div>";
            echo "<div class=\"availability-text\">$carCount taken / $carTotal total</div>";
            if ($carPercentage >= 0 && $carPercentage <=50){
              echo "<div class=\"status-pill status-good\">Plenty of spaces</div>";
            }
            else if ($carPercentage > 50 && $carPercentage <= 85)
            {
              echo "<div class=\"status-pill status-medium\">Almost Full</div>";
            }
            else{
              echo "<div class=\"status-pill status-bad\">Good Luck</div>";
            }
          ?>

          <!-- Link this to your layout page -->
          <a href="Lot 1.php" class="view-button">View Lot Layout</a>
        </div>

        <!-- Lot 2 card -->
        <div class="lot-card">
          <div class="lot-name">Lot 2</div>
          <div class="lot-tagline">Closer to Student Union</div>

          <div class="availability-bar">
            <div class="availability-fill" style="width: 0%; background-color:#FFB81C;"></div>
          </div>
          <div class="availability-text">## open / 40 total</div>
          <div class="status-pill status-medium">Under Construction</div>

          <a href="Coming Soon.php" class="view-button">View Lot Layout</a>
        </div>

        
      </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        Home Page
    </div>
  </div>
</body>
</html>
